AWS.config.region = 'eu-west-1'; // Region
AWS.config.credentials = new AWS.Credentials('AKIAIN4AYBLH6UO5F5AA', 'LXJml7z2byIxKA5aYRvLjRee00MGm4BD3vz0BTWy');