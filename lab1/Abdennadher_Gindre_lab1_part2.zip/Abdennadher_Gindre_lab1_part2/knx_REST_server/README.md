* usage: 

```shell
knx_server.py [-h] -gwip GATEWAY_IP -gwprt GATEWAY_PORT -endport ENDPOINT_PORT
```

arguments:
  -h, --help            show this help message and exit
  -gwip GATEWAY_IP, --gateway_ip GATEWAY_IP
                        Gateway ip
  -gwprt GATEWAY_PORT, --gateway_port GATEWAY_PORT
                        Gateway port
  -endport ENDPOINT_PORT, --endpoint_port ENDPOINT_PORT
                        Endpoint port

* Exemple of use with the `actuasim.py` simulator:

```shell
python3 knx_server.py -gwip 127.0.0.1 -gwprt 3671 -endport 2672
```

* To read the documentation of the REST server : `apidoc/index.html`