In the `backend.py` file, we implemented the following methods:

* get_nodes_list
* get_sensors_list
* get_luminance
* get_motion
* get_battery
* get_all_Measures
* get_dimmers
* get_dimmer_level
* set_dimmer_level
* set_basic_nodes_configuration
* get_nodes_Configuration
* network_info

